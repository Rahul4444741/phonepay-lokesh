import * as React from "react";
const SVGComponent = (props) => (
  <svg
    width={1193}
    height={157}
    viewBox="0 0 1193 157"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    {...props}
  >
    <rect width={1193} height={157} rx={12} fill="#53389E" />
  </svg>
);
export default SVGComponent;
