import { useEffect, useState } from "react";
import APIList from "../../../api"

import { RiErrorWarningFill } from "react-icons/ri"
import { toast } from "react-toastify"
const useEmployee = ()=>{
  const [promisedata ,setPromisedata]=useState([]);
  const [profileinfodata ,setProfileinfodata]=useState([]);
  const [profiledata ,setProfiledata]=useState([]);

    
 
  useEffect(() => {
  APIList.getPerformanceData({
            payload: {
                employeeEligibilityDTO: {},
                filterData: false,
                keyword: "",
               
                employedId:"6e534989-4f22-489e-88ff-2a96928b7d2c",
                page: "My Team"
            },
            
        }).then((res )=> 
        setPromisedata(res.data)
        ).catch(err => console.log(err))
  },[])
  
useEffect(() => {
    APIList.getProfileinfoData({
              payload: {
                  employeeEligibilityDTO: {},
                  filterData: false,
                  keyword: "",
                  // managerId: employeeDetails?.id,
                  // companyId: employeeDetails?.company?.id,
                  managerId: "4b6fa605-ba6c-41ed-8d35-6159cf78c6de",
                  companyId: "ba02f418-e44d-467c-9d5d-421a2d966460",
                  employedId:"6e534989-4f22-489e-88ff-2a96928b7d2c",
                  page: "My Team"
              },
              
          }).then((res )=> 
          setProfileinfodata(res.data)
          ).catch(err => console.log(err))
      //console.log("__", data)
    },[])

useEffect(() => {
        APIList.getProfileData({
                  payload: {
                      employeeEligibilityDTO: {},
                      filterData: false,
                      keyword: "",
                      // managerId: employeeDetails?.id,
                      // companyId: employeeDetails?.company?.id,
                      "managerId": "4b6fa605-ba6c-41ed-8d35-6159cf78c6de",
                      "companyId": "ba02f418-e44d-467c-9d5d-421a2d966460",
                      employedId:"6e534989-4f22-489e-88ff-2a96928b7d2c",
                      page: "My Team"
                  },
                  
              }).then((res )=> 
              setProfiledata(res.data)
              ).catch(err => console.log(err))
          //console.log("__", data)
        },[])    
    
  return {
promisedata,
profileinfodata,
profiledata
  }
}
export default useEmployee;