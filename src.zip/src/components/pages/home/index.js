const Home = () => {
    return(
        <div className="phonepay-home-main">
            <p className="header-title">Homepage</p>
        </div>
    )
}

export default Home;