import { handleActions } from 'redux-actions';
import { types } from './actions';

const actionHandler = {
    [types.EMPLOYEE_DATA_REQUEST]: (state) => ({
        ...state,
        loader: true,
    }),
    [types.EMPLOYEE_DATA_REQUEST_SUCCESS]: (state, { payload }) => ({
        ...state,
        loader: false,
        empData: payload || {},
    }),
    [types.EMPLOYEE_DATA_REQUEST_FAILED]: (state) => ({
        ...state,
        loader: false,
    }),   
    [types.PERFORMANCE_HISTORY]: (state) => ({
        ...state,
        loader: true,
    }),
    [types.PERFORMANCE_HISTORY_SUCCESS]: (state, { payload }) => ({
        ...state,
        loader: false,
        performanceHistory: payload || {},
    }),
    [types.PERFORMANCE_HISTORY_FAILED]: (state) => ({
        ...state,
        loader: false,
    }),   
};

export default handleActions(actionHandler, {
    loader: false,
    empData: {},   
    performanceHistory:{}
});
